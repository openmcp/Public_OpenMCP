import React, { Component } from "react";

class SnapshotLog extends Component {
  render() {
    return (
      <div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
      </div>
    );
  }
}

export default SnapshotLog;
