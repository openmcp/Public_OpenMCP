import React, { Component } from 'react';

class Pj_Settings extends Component {
    render() {
        return (
            <div className="content-wrapper">
                This is Settings page.
                
            </div>
        );
    }
}

export default Pj_Settings;