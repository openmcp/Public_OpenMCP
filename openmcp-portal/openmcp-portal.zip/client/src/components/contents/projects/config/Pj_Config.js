import React, { Component } from 'react';

class Pj_Config extends Component {
    render() {
        return (
            <div className="content-wrapper">
                This is Conifg page.
                
            </div>
        );
    }
}

export default Pj_Config;