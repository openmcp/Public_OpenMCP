import React, { Component } from 'react';

class Pj_Volumes extends Component {
    render() {
        return (
            <div className="content-wrapper">
                This is Volumes page.
                
            </div>
        );
    }
}

export default Pj_Volumes;