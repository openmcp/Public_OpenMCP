import React, { Component } from 'react';

class Pj_Ingress extends Component {
    render() {
        return (
            <div className="content-wrapper">
                This is Ingress page.
            </div>
        );
    }
}

export default Pj_Ingress;