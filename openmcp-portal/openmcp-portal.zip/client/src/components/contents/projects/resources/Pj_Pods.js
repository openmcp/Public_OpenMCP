import React, { Component } from 'react';

class Pj_Pods extends Component {
    render() {
        return (
            <div className="content-wrapper">
                This is Pods page.
                
            </div>
        );
    }
}

export default Pj_Pods;