import React, { Component } from 'react';

class Pj_Services extends Component {
    render() {
        return (
            <div className="content-wrapper">
                This is Services page.
                
            </div>
        );
    }
}

export default Pj_Services;