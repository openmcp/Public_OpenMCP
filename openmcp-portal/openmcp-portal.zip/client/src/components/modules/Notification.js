// import React from "react";
// import { ToastContainer, toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// // import { useHistory } from "react-router-dom";
// // import * as noti from './../modules/Notification.js';
// // noti.fn_notification("warn",'aaaaa','/dddd/ddd/dd');

// // function HomeButton() {
// //   console.log("HomeButton");
// //   const history = useHistory();
// //   history.push("/nodes/cluster2-master.dev.gmd.life?clustername=cluster2");
// // }

// export function fn_notification(type, message, url, prs) {
//   // const notify = () => {
    
//     let history = prs;
    
//     function handleClick(props) {
//       // const history = useHistory();
//       // history.push("/nodes/cluster2-master.dev.gmd.life?clustername=cluster2");
//     // this.props.info.history.push(url);
//     debugger;
//     console.log('dkdkdkdkdk');
//   }
  

//   if (type == "warn") {
//     toast.warn(message, {
//       position: toast.POSITION.BOTTOM_RIGHT,
//       autoClose: 5000,
//       hideProgressBar: false,
//       closeOnClick: true,
//       pauseOnHover: true,
//       draggable: true,
//       progress: undefined,
//       pauseOnFocusLoss: false,
//       onClick: props => handleClick(props),
//     });
//   } else {
//     toast.error(message, {
//       position: toast.POSITION.BOTTOM_RIGHT,
//       autoClose: 5000,
//       hideProgressBar: false,
//       closeOnClick: true,
//       pauseOnHover: true,
//       draggable: true,
//       progress: undefined,
//       pauseOnFocusLoss: false,
//       onClick: props => handleClick(props),
//     });
//   }
//   // };
// }
