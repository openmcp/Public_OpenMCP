import React, { Component } from 'react';

class LineReChart extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default LineReChart;