import React, { Component } from 'react';

class LineReAreaChart extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}

export default LineReAreaChart;