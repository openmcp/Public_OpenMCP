import React, { Component } from 'react';

class SignUp extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default SignUp;