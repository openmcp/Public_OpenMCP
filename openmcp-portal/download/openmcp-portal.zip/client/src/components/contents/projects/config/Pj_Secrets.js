import React, { Component } from 'react';

class Pj_Secrets extends Component {
    render() {
        return (
            <div className="content-wrapper">
                This is Secrets page.
            </div>
        );
    }
}

export default Pj_Secrets;