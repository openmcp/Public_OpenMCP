import React, { Component } from "react";

class Snapshot extends Component {
  render() {
    return (
      <div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
        <div>Snapshot List with calendar</div>
      </div>
    );
  }
}

export default Snapshot;
