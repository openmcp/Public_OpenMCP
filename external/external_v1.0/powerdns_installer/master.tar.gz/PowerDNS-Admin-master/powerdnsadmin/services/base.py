from authlib.flask.client import OAuth

authlib_oauth_client = OAuth()