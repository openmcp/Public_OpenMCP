package resource

type Deployment struct {
	Name      string  
}

type Deployments []Deployment